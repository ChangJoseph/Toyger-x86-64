#!/bin/bash
gcc -g -o $1 $1.s
echo "$1 created"
